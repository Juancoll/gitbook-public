/**************************************************

	Programa de Demo de Les GLClass.

	Autor : Juan Coll Soler
	data  : 11-11-01
	e-mail: tm06521@Salleurl.edu

**************************************************/

#include <iostream.h>

#include "../GLClass source/GLClass.h"
#include "../OpenSIM source/OpenSim.h"

#include <GL/glut.h>
#include <stdlib.h>
#include <time.h>

// --Variables Globals

	// -- Variables GLClass  

GLViewer		GLViewer01;		
GLViewer		GLViewer02;
GLLight			GLLight01;
GLDeviceControl	GLDeviceControl01;
 
GLImage			GLImage01;
GLTexture		GLTexture01;

	// -- Variables OpenSIM
Logo			logo;

ParticleSystem ps;
Solver		solver;
OpenGLOutput openGLOutput;


int size = 10;
float particleColor[] = {1,0.8,1,1};

bool running = false;
// -- Function integrator funcion

void calculateForce(ParticleSystem *ps, double t)
{
}

void explose(ParticleSystem &ps, int amplitud)
{
	float tmp = (float)(amplitud)/2;
	for (int i = 0 ; i < ps.getNumOfParticles()  ; i++)
	{
		ps.getParticleAt(i).getPosition().set(0,0,0);
		ps.getParticleAt(i).getSpeed().set(rand()%amplitud- tmp,rand()%amplitud- tmp,rand()%amplitud - tmp);
	}
}

// -- Funcions 

void particleRender()
{
	glEnable(GL_BLEND);
   	glBlendFunc(GL_SRC_ALPHA,GL_ONE);	
	glDisable(GL_CULL_FACE);
	
	glDepthMask(GL_FALSE);

	glColor4fv(particleColor);
	float Side = size/2;

	glBegin(GL_TRIANGLE_STRIP);						
		glTexCoord2d(1,1); glVertex3f(+Side,+Side,0.0f);
		glTexCoord2d(0,1); glVertex3f(-Side,+Side,0.0f); 
		glTexCoord2d(1,0); glVertex3f(+Side,-Side,0.0f);
		glTexCoord2d(0,0); glVertex3f(-Side,-Side,0.0f); 
	glEnd();	

	glDepthMask(GL_TRUE);
	glEnable(GL_CULL_FACE);
	glDisable(GL_BLEND);
}
bool init( int argc, char ** argv );


// -- Funcions de CallBack 

void display();
void idle();
void reshape( int width, int height );
void keyboard(unsigned char key, int x, int y);
void keyboardUp(unsigned char key, int x, int y);
void special(int key, int x, int y);
void specialUp(int key, int x, int y);
void mouse(int button, int state, int x, int y);
void motion(int x, int y);
void passiveMotion(int x, int y);


// -- Programa principal

int main( int argc, char ** argv )
{

	// Inicialitzacio de la finestra OpenGL
	glutInit( &argc,argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH );
	glutInitWindowPosition( 0, 0 );
	glutInitWindowSize( 500, 500);
	glutCreateWindow("Demo de OpenSIM");

	// Inicialitzem el programa --> si Error sortim
	if( !init( argc, argv ) ) exit(0);
	

	// Inicialitzacio dels Callbacks
	glutDisplayFunc(display);
	glutIdleFunc(idle);
	glutReshapeFunc(reshape);

	glutKeyboardFunc(keyboard);
	glutKeyboardUpFunc(keyboardUp);
	glutSpecialFunc(special);
	glutSpecialUpFunc(specialUp);
	glutMouseFunc(mouse);
	glutMotionFunc(motion);
	glutPassiveMotionFunc(passiveMotion);

	// Bucle del Programa
	glutMainLoop();
	
	return 0;
}

// -- Implementacio de les Funcions
 
bool init( int argc, char ** argv )
{
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_POINT_SMOOTH);
	// -- Inicialitzem OpenGL
	glPointSize(4);
	glEnable(GL_DEPTH_TEST);								// active the depth buffer
//	glEnable(GL_LIGHTING);									// active lights
	glEnable(GL_COLOR_MATERIAL);							// active glColor = Material (it's for lights
	glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);		// the active color = material ambient & diffuse	


	// -- Inicialitzem el Primer Viewer
	GLViewer01.setClearColor( 0.0, 0.0, 0.0, 0 );			// Color de fons del viewer
	GLViewer01.setProjectionType( GLVIEWER_PERSPECTIVE );	// Seleccionem el tipus de Projeccio del Viewer
	GLViewer01.setLookAt( 0,0,500,						// Posicio de la camara
							0,  0,  0,						// Posicio del punt de mira
							0,  1,  0);						// Orientacio de la camara


	// -- Inicialitzem el segon Viewer
	GLViewer02.setClearColor( 0.226, 0.459, 0.644 , 1.0 );	// Color de fons del viewer
	GLViewer02.setProjectionType( GLVIEWER_PERSPECTIVE );	// Seleccionem el tipus de Projeccio del Viewer
	GLViewer02.setLookAt( 30, 30, 30,						// Posicio de la camara
						   0,  0,  0,						// Posicio del punt de mira
						   0,  1,  0);						// Orientacio de la camara

	// -- Inicialitzem la Llum GLLight01
	GLLight01.setPosition(300,300,300);

	
	GLBMPParser::load("./Textures/Particle3.bmp", GLImage01 );
	GLTexture01.createFromGLImage( GLImage01, 0);
	GLImage01.clear();

	// Proves de Colisions.

	srand((unsigned)time( NULL )); 

	ps.setNumOfParticles(500);

	cout << "Space  -->  Simulation  Start/Stop" << endl;
	cout << "e      -->  Explose	" << endl;
				
	return true;
}


// -- Implementacio de les funcions de CallBacks

void display()
{
	// -- Nategem la finestra
	glClearDepth( 1.0f );									// Valor de Z-Buffer
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );					// Color de Fons 
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );	// Esborrem 


	// --  Viewer01

	GLViewer01.active();									// Activem el Viewer01
		GLViewer01.enableLookAt();							// Activem la seva matriu de LookAt

			GLDeviceControl01.enable();
			
		

				glEnable(GL_TEXTURE_2D);
				GLTexture01.enableTextureAt(0);

				openGLOutput.render(ps, particleRender );
				

				glDisable( GL_TEXTURE_2D );			

			GLDeviceControl01.disable();

		GLViewer01.disableLookAt();							// Desactivem el LookAt

	// -- Viewer02
	GLViewer02.active();									// Activem el Viewer02
		GLViewer02.enableLookAt();							// Activem la seva matriu de LookAt

			GLLight01.enable();
			
				logo.openGLRender(10,2);

			GLLight01.disable();

		GLViewer02.disableLookAt();							// Desactivem el LookAt

	
	glutSwapBuffers();
}
void idle()
{

	if (running) solver.euler(ps, calculateForce );


	glutPostRedisplay();
}
void reshape( int width, int height )
{
	GLViewer01.setPositionAndSize(20,20,width - 40, height - 40);		// Posicionem i dimensionem el GLViewer01 en funcio del tamany de la finestra
	GLViewer02.setPositionAndSize(width  - 70, 30, 40, 40);				// Posicionem i dimensionem el GLViewer02 en funcio del tamany de la finestra 

	if (height==0)	height=1;											// Evitem una possible divisio per 0								

	GLViewer01.setPerspAspectRatio((GLfloat)(width)/(GLfloat)height);	// Calculem el Aspect Ratio del Viewer01
	GLViewer02.setPerspAspectRatio(1);									// inicialitzam el Aspect Ratio del Viewer02
}

void keyboard(unsigned char key, int x, int y)
{
	switch(key)
	{
		case 'e':	explose(ps, 100);
		case ' ': (running == true)?running = false : running = true;break; 

	}
}
void keyboardUp(unsigned char key, int x, int y)
{
	switch(key)
	{
	}
}
void special(int key, int x, int y)
{
}
void specialUp(int key, int x, int y)
{
}
void mouse(int button, int state, int x, int y)
{
	if(button == GLUT_LEFT_BUTTON)
	{
		switch(state)
		{
			case GLUT_DOWN: 
				GLDeviceControl01.LMouseDown( x, y );
				break;
			case GLUT_UP:
				GLDeviceControl01.LMouseUp( x, y );
		}
	}

	if(button == GLUT_RIGHT_BUTTON)
	{
		switch(state)
		{
			case GLUT_DOWN: 
				GLDeviceControl01.RMouseDown( x, y );
				break;
			case GLUT_UP:
				GLDeviceControl01.RMouseUp( x, y );
		}
	}

	glutPostRedisplay();
}
void motion(int x, int y)
{
	GLDeviceControl01.mouseMove( x, y);
}
void passiveMotion(int x, int y)
{
}