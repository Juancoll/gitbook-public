/**************************************************

	Programa de Demo de Les GLClass.

	Autor : Juan Coll Soler
	data  : 11-11-01
	e-mail: tm06521@Salleurl.edu

**************************************************/

#include <iostream.h>

#include "../../GLClass Source/GLClass.h"
#include "../../OpenSIM Source/OpenSim.h"

#include <GL/glut.h>

// --Variables Globals 

GLViewer		GLViewer01;		
GLViewer		GLViewer02;
GLLight			GLLight01;
GLDeviceControl	GLDeviceControl01;

GLImage			GLImage01;
GLTexture		GLTexture01;
Logo			logo;

// Variable globales de OpenSIM
SpringSystem    ss;
Mesh			mesh;
Plane			plane1;
Plane			plane2;

Vector3D_d		gravity(0,-9,0);

Solver			solver;
OpenGLOutput	openGLOutput;

bool running = false;
bool drawSS	 = true;
bool drawMesh = true;

// -- Funcions 

bool createDeformableCube(SpringSystem &ss, double size, double kd, double ks)
{
	double k = size / 2;

	ss.setNumOfParticles(8);
	ss.setNumOfSprings(28);

	ss.getParticleAt(0).getPosition().set(-k,-k,-k);
	ss.getParticleAt(1).getPosition().set( k,-k,-k);
	ss.getParticleAt(2).getPosition().set(-k,-k, k);
	ss.getParticleAt(3).getPosition().set( k,-k, k);
	ss.getParticleAt(4).getPosition().set(-k, k,-k);
	ss.getParticleAt(5).getPosition().set( k, k,-k);
	ss.getParticleAt(6).getPosition().set(-k, k, k);
	ss.getParticleAt(7).getPosition().set( k, k, k);

	int count = 0;

	for(int i = 0 ; i < 8 - 1 ; i++ )
	{
		for(int j = i + 1; j < 8 ; j++)
		{
			ss.getSpringAt(count).setParticles(ss.getParticleAt(i), ss.getParticleAt(j));
			ss.getSpringAt(count).setConstants(ss.getParticleAt(i).getPosition().distance(ss.getParticleAt(j).getPosition()), kd, ks );
			count++;
		}
	}
	return true;
}


void calculateForce(ParticleSystem *sp, double t)
{
	sp->resetForce();
	((SpringSystem*)sp)->calculateForce();
	
	Force::constant(*sp,gravity);
}

//--

bool init( int argc, char ** argv );


// -- Funcions de CallBack 

void display();
void idle();
void reshape( int width, int height );
void keyboard(unsigned char key, int x, int y);
void keyboardUp(unsigned char key, int x, int y);
void special(int key, int x, int y);
void specialUp(int key, int x, int y);
void mouse(int button, int state, int x, int y);
void motion(int x, int y);
void passiveMotion(int x, int y);


// -- Programa principal

int main( int argc, char ** argv )
{

	// Inicialitzacio de la finestra OpenGL
	glutInit( &argc,argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH );
	glutInitWindowPosition( 0, 0 );
	glutInitWindowSize( 800, 800);
	glutCreateWindow("Demo de OpenSim");

	// Inicialitzem el programa --> si Error sortim
	if( !init( argc, argv ) ) exit(0);
	

	// Inicialitzacio dels Callbacks
	glutDisplayFunc(display);
	glutIdleFunc(idle);
	glutReshapeFunc(reshape);

	glutKeyboardFunc(keyboard);
	glutKeyboardUpFunc(keyboardUp);
	glutSpecialFunc(special);
	glutSpecialUpFunc(specialUp);
	glutMouseFunc(mouse);
	glutMotionFunc(motion);
	glutPassiveMotionFunc(passiveMotion);

	// Bucle del Programa
	glutMainLoop();
	
	return 0;
}

// -- Implementacio de les Funcions

bool init( int argc, char ** argv )
{
	// -- Inicialitzem OpenGL
	glEnable(GL_DEPTH_TEST);								// active the depth buffer
//	glEnable(GL_LIGHTING);									// active lights
	glEnable(GL_COLOR_MATERIAL);							// active glColor = Material (it's for lights
	glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);		// the active color = material ambient & diffuse	
	glPointSize(3);


	// -- Inicialitzem el Primer Viewer
	GLViewer01.setClearColor( 0.7, 0.7 ,0.7 ,0 );			// Color de fons del viewer
	GLViewer01.setProjectionType( GLVIEWER_PERSPECTIVE );	// Seleccionem el tipus de Projeccio del Viewer
	GLViewer01.setLookAt( 400,400,400,						// Posicio de la camara
							0,  0,  0,						// Posicio del punt de mira
							0,  1,  0);						// Orientacio de la camara


	// -- Inicialitzem el segon Viewer
	GLViewer02.setClearColor( 0.226, 0.459, 0.644 , 1.0 );	// Color de fons del viewer
	GLViewer02.setProjectionType( GLVIEWER_PERSPECTIVE );	// Seleccionem el tipus de Projeccio del Viewer
	GLViewer02.setLookAt( 30, 30, 30,						// Posicio de la camara
						   0,  0,  0,						// Posicio del punt de mira
						   0,  1,  0);						// Orientacio de la camara

	// -- Inicialitzem la Llum GLLight01
	GLLight01.setPosition(300,300,300);

	GLImage image;
	
	GLBMPParser::load("./Textures/ropa.bmp", image);
	GLTexture01.createFromGLImage(image,0);
	image.clear();
	GLBMPParser::load("./Textures/pla01.bmp", image);
	GLTexture01.createFromGLImage(image,1);
	image.clear();
	GLBMPParser::load("./Textures/pla02.bmp", image);
	GLTexture01.createFromGLImage(image,2); 
	image.clear();

	Point3D_d	p(0,0,0);
	Vector3D_d	n(0,1,0);
	plane1.set( n, p);

	p.set(0,20,0);
	n.set(0,1,1);
	plane2.set( n, p);

	Vector3D_d  v;
	::createDeformableCube(ss, 30,10,1);

	Matrix3D_d m;
/*	
	v.set(1,0,0);
	m.setRotation(40,v);
	ss *= m;
*/
	v.set(0,150,-40);
	m.setTranslation(v);
	ss *= m;


	Import::ASEFileToMesh("./meshes/cubo.ase",mesh);
	mesh.assignToParticleSystem(ss);
	
	cout << "Space  -->  Simulation  Start/Stop" << endl;
	cout << "s      -->  Show/hide   Spring System" << endl;
	cout << "m		-->  Show/hide	 Mesh		 " << endl;

	return true;
}


// -- Implementacio de les funcions de CallBacks

void display()
{
	// -- Nategem la finestra
	glClearDepth( 1.0f );									// Valor de Z-Buffer
	glClearColor( 1.0f, 1.0f, 1.0f, 1.0f );					// Color de Fons 
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );	// Esborrem 

	// --  Viewer01

	GLViewer01.active();									// Activem el Viewer01
		GLViewer01.enableLookAt(); 							// Activem la seva matriu de LookAt
			
	//		GLLight01.enable();
				

				GLDeviceControl01.enable();
					// Pla horitzontal
					glColor3f(1,1,1);
					glEnable(GL_TEXTURE_2D);
					GLTexture01.enableTextureAt(1);
					GLGeometry::planeXZ(200,400,5);
					glPushMatrix();
						glTranslatef(0,0,20);
						glRotatef(45, 1,0,0);
						GLTexture01.enableTextureAt(2);
						GLGeometry::planeXZ(200,300,5);						
					glPopMatrix();
					glDisable(GL_TEXTURE_2D);

					if( drawSS ) openGLOutput.render(ss, true, true, false, true);

					if( drawMesh)
					{
						glEnable(GL_TEXTURE_2D);
						GLTexture01.enableTextureAt(0);
						openGLOutput.render(mesh,false,false,true,false,false,0,true);
						glDisable(GL_TEXTURE_2D);
					}
				
				GLDeviceControl01.disable();

	//		GLLight01.disable();

		GLViewer01.disableLookAt();							// Desactivem el LookAt

	// -- Viewer02
	GLViewer02.active();									// Activem el Viewer02
		GLViewer02.enableLookAt();							// Activem la seva matriu de LookAt

			GLLight01.enable();
			
				logo.openGLRender(10,2);

			GLLight01.disable();

		GLViewer02.disableLookAt();							// Desactivem el LookAt

	
	glutSwapBuffers();
}
void idle()
{

	ParticleSystem tmp;

	tmp.setNumOfParticles(8);

	if ( running)
	{
		
		bool ok = false;

		while(!ok)
		{
			for( int i = 0 ; i < 8 ; i++) tmp.getParticleAt(i) = ss.getParticleAt(i);

			solver.rungeKutta4(ss, calculateForce);

			for( i = 0 ; i < ss.getNumOfParticles() ; i++)
			{
				if( plane1.isCollisionBetweenPlaneAndSegment(ss.getParticleAt(i).getPosition(),tmp.getParticleAt(i).getPosition()) )
				{
					ss.getParticleAt(i).getPosition() = plane1.symetricDumpedPoint( 0.8,  ss.getParticleAt(i).getPosition() );
					ss.getParticleAt(i).getSpeed()    = plane1.symetricDumpedVector( 0.8, ss.getParticleAt(i).getSpeed() )*0.7;
					continue;
				}
				if( plane2.isCollisionBetweenPlaneAndSegment(ss.getParticleAt(i).getPosition(),tmp.getParticleAt(i).getPosition()) )
				{
					ss.getParticleAt(i).getPosition() = plane2.symetricDumpedPoint( 0.8,  ss.getParticleAt(i).getPosition() );
					ss.getParticleAt(i).getSpeed()    = plane2.symetricDumpedVector( 0.8, ss.getParticleAt(i).getSpeed() )*0.3;
					continue;
				}
				
			}
			if ( i == 8 ) ok = true;
		}
	}

	glutPostRedisplay();
}
void reshape( int width, int height )
{
	GLViewer01.setPositionAndSize(20,20,width - 40, height - 40);		// Posicionem i dimensionem el GLViewer01 en funcio del tamany de la finestra
	GLViewer02.setPositionAndSize(width  - 70, 30, 40, 40);				// Posicionem i dimensionem el GLViewer02 en funcio del tamany de la finestra 

	if (height==0)	height=1;											// Evitem una possible divisio per 0								

	GLViewer01.setPerspAspectRatio((GLfloat)(width)/(GLfloat)height);	// Calculem el Aspect Ratio del Viewer01
	GLViewer02.setPerspAspectRatio(1);									// inicialitzam el Aspect Ratio del Viewer02
}

void keyboard(unsigned char key, int x, int y)
{
	switch(key)
	{
		case ' ': (running == true)?running = false : running = true;break; 
		case 's': (drawSS == true)?drawSS = false : drawSS = true; break;
		case 'm': (drawMesh == true)?drawMesh = false : drawMesh = true; break;
 
	}
}
void keyboardUp(unsigned char key, int x, int y)
{
}
void special(int key, int x, int y)
{
}
void specialUp(int key, int x, int y)
{
}
void mouse(int button, int state, int x, int y)
{
	if(button == GLUT_LEFT_BUTTON)
	{
		switch(state)
		{
			case GLUT_DOWN: 
				GLDeviceControl01.LMouseDown( x, y );
				break;
			case GLUT_UP:
				GLDeviceControl01.LMouseUp( x, y );
		}
	}

	if(button == GLUT_RIGHT_BUTTON)
	{
		switch(state)
		{
			case GLUT_DOWN: 
				GLDeviceControl01.RMouseDown( x, y );
				break;
			case GLUT_UP:
				GLDeviceControl01.RMouseUp( x, y );
		}
	}

	glutPostRedisplay();
}
void motion(int x, int y)
{
	GLDeviceControl01.mouseMove( x, y);
}
void passiveMotion(int x, int y)
{
}